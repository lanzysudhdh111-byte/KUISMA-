package com.lanz.kuisma;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.media.MediaPlayer;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;
    private SharedPreferences prefs;
    private VideoView backgroundVideo;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);

        // Full-bleed background: draw behind status/navigation bars.
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 13, 25));

        backgroundVideo = new VideoView(this);
        FrameLayout.LayoutParams videoParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(backgroundVideo, videoParams);
        int videoId = getResources().getIdentifier("panel_bg", "raw", getPackageName());
        if (videoId != 0) {
            Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + videoId);
            backgroundVideo.setVideoURI(videoUri);
            backgroundVideo.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                mp.setVolume(0f, 0f);
                // Crop the portrait video to cover the whole screen instead of letterboxing.
                if (Build.VERSION.SDK_INT >= 24) {
                    mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
                }
                backgroundVideo.start();
            });
            backgroundVideo.setOnErrorListener((mp, what, extra) -> true);
        }

        View tint = new View(this);
        tint.setBackgroundColor(0x66040A18);
        root.addView(tint, videoParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(14), dp(18), dp(14), dp(24));
        FrameLayout.LayoutParams scrollParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(scroll, scrollParams);
        scroll.setVisibility(View.GONE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(22), dp(20), dp(22));
        panel.setBackground(rounded(0x99202B40, 0x66FFFFFF, 24));
        scroll.addView(panel, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("KUISMA  ·  AI WEB");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Aktifkan tombol melayang untuk membuka Gemini dalam jendela kecil di atas aplikasi lain.");
        intro.setTextColor(0xFFE8EDF7);
        intro.setTextSize(16);
        intro.setPadding(0, dp(12), 0, dp(18));
        panel.addView(intro);

        Button enable = glassButton("AKTIFKAN TOMBOL MELAYANG");
        panel.addView(enable, buttonParams());
        Button stop = glassButton("MATIKAN TOMBOL MELAYANG");
        panel.addView(stop, buttonParams());

        TextView settingsTitle = new TextView(this);
        settingsTitle.setText("Pengaturan tombol buka Gemini");
        settingsTitle.setTextColor(Color.WHITE);
        settingsTitle.setTextSize(19);
        settingsTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        settingsTitle.setPadding(0, dp(24), 0, dp(8));
        panel.addView(settingsTitle);

        addSlider(panel, "Ukuran tombol buka Gemini", "bubble_size", 40, 100, 56, " dp");
        addSlider(panel, "Transparansi tombol buka Gemini", "bubble_opacity", 0, 100, 85, "%");

        TextView note = new TextView(this);
        note.setText("Pengaturan ini mengubah tombol bulat <> untuk membuka Gemini, bukan ukuran jendela web Gemini. Perubahan diterapkan langsung saat tombol melayang aktif.");
        note.setTextColor(0xFFDCE5F4);
        note.setTextSize(13);
        note.setPadding(0, dp(14), 0, dp(4));
        panel.addView(note);

        // Halaman pembuka: hanya judul, label developer, dan tombol Login.
        LinearLayout welcome = new LinearLayout(this);
        welcome.setOrientation(LinearLayout.VERTICAL);
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(dp(28), dp(28), dp(28), dp(28));
        FrameLayout.LayoutParams welcomeParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(welcome, welcomeParams);

        TextView welcomeTitle = new TextView(this);
        welcomeTitle.setText("APK KUISMA");
        welcomeTitle.setTextColor(Color.WHITE);
        welcomeTitle.setTextSize(34);
        welcomeTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        welcomeTitle.setGravity(Gravity.CENTER);
        welcomeTitle.setShadowLayer(dp(12), 0, 0, 0xCC168BFF);
        welcome.addView(welcomeTitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView developer = new TextView(this);
        developer.setText("developer: LanzXytre");
        developer.setTextColor(0xFFDCE5F4);
        developer.setTextSize(13);
        developer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams devParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        devParams.setMargins(0, dp(8), 0, dp(28));
        welcome.addView(developer, devParams);

        Button login = glassButton("LOGIN");
        login.setTextSize(16);
        login.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams loginParams = new LinearLayout.LayoutParams(
                dp(220), dp(54));
        welcome.addView(login, loginParams);
        login.setOnClickListener(v -> {
            welcome.setVisibility(View.GONE);
            scroll.setVisibility(View.VISIBLE);
        });

        setContentView(root);
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else startBubble();
        });
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, BubbleService.class));
            Toast.makeText(this, "Tombol melayang dimatikan.", Toast.LENGTH_SHORT).show();
        });
    }

    private Button glassButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.setBackground(rounded(0x663B82F6, 0x99FFFFFF, 30));
        if (Build.VERSION.SDK_INT >= 21) b.setElevation(dp(3));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        p.setMargins(0, dp(6), 0, dp(7));
        return p;
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void addSlider(LinearLayout parent, String title, String key, int min, int max, int fallback, String suffix) {
        int current = prefs.getInt(key, fallback);
        TextView label = new TextView(this);
        label.setText(title + ": " + current + suffix);
        label.setTextColor(0xFFF3F6FC);
        label.setTextSize(15);
        label.setPadding(0, dp(12), 0, 0);
        parent.addView(label);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(Math.max(0, Math.min(max - min, current - min)));
        parent.addView(seek, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = min + progress;
                label.setText(title + ": " + value + suffix);
                if (fromUser) {
                    prefs.edit().putInt(key, value).apply();
                    sendBubbleSettingsChanged();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }
    private void sendBubbleSettingsChanged() {
        Intent update = new Intent("com.lanz.kuisma.BUBBLE_SETTINGS_CHANGED");
        update.setPackage(getPackageName());
        sendBroadcast(update);
    }

    @Override protected void onResume() {
        super.onResume();
        if (backgroundVideo != null && !backgroundVideo.isPlaying()) backgroundVideo.start();
    }

    @Override protected void onPause() {
        if (backgroundVideo != null && backgroundVideo.isPlaying()) backgroundVideo.pause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (backgroundVideo != null) backgroundVideo.stopPlayback();
        super.onDestroy();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startBubble();
    }

    private void startBubble() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, BubbleService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Tombol melayang diaktifkan.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengaktifkan tombol: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
