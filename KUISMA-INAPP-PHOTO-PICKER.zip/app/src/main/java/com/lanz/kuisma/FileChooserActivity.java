package com.lanz.kuisma;

import android.app.Activity;
import android.Manifest;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.ValueCallback;
import java.util.ArrayList;

/** KUISMA-branded in-app image picker. */
public class FileChooserActivity extends Activity {
    private static final int REQUEST_IMAGES = 7413;
    private final ArrayList<Uri> images = new ArrayList<>();
    private GridView grid;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 18, 30));
        getWindow().setNavigationBarColor(Color.BLACK);
        buildShell();
        if (hasImagePermission()) loadImages();
        else requestImagePermission();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 18, 30));
        root.setPadding(dp(14), dp(12), dp(14), dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("Pilih foto · KUISMA");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView cancel = new TextView(this);
        cancel.setText("BATAL");
        cancel.setTextColor(Color.rgb(160, 195, 255));
        cancel.setTextSize(13);
        cancel.setPadding(dp(12), dp(12), dp(4), dp(12));
        cancel.setOnClickListener(v -> finishWithResult(null));
        header.addView(cancel);
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Pilih gambar dari perangkat untuk dikirim ke Gemini");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(5));
        grid.setVerticalSpacing(dp(5));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < images.size()) finishWithResult(new Uri[]{images.get(position)});
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private boolean hasImagePermission() {
        String permission = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_IMAGES" : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestImagePermission() {
        String permission = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_IMAGES" : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermissions(new String[]{permission}, REQUEST_IMAGES);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_IMAGES) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) loadImages();
            else {
                Toast.makeText(this, "Izin foto diperlukan untuk memilih gambar", Toast.LENGTH_LONG).show();
                finishWithResult(null);
            }
        }
    }

    private void loadImages() {
        images.clear();
        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Images.Media._ID };
        try (Cursor cursor = getContentResolver().query(collection, projection, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (cursor != null) {
                int idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idColumn);
                    images.add(ContentUris.withAppendedId(collection, id));
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membaca galeri: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        grid.setAdapter(new ImageAdapter());
        if (images.isEmpty()) Toast.makeText(this, "Belum ada foto yang dapat ditampilkan", Toast.LENGTH_LONG).show();
    }

    private class ImageAdapter extends BaseAdapter {
        @Override public int getCount() { return images.size(); }
        @Override public Object getItem(int position) { return images.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            ImageView image = convertView instanceof ImageView ? (ImageView) convertView : new ImageView(FileChooserActivity.this);
            int size = getResources().getDisplayMetrics().widthPixels / 3;
            image.setLayoutParams(new GridView.LayoutParams(-1, size));
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(Color.rgb(30, 40, 58));
            image.setImageURI(images.get(position));
            return image;
        }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void finishWithResult(Uri[] result) {
        ValueCallback<Uri[]> callback = BubbleService.pendingFileCallback;
        BubbleService.pendingFileCallback = null;
        if (callback != null) callback.onReceiveValue(result);
        finish();
    }

    @Override public void onBackPressed() { finishWithResult(null); }
}
