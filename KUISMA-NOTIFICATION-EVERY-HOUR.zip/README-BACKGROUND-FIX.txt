KUISMA background full-screen fix
- Video background is set to scale-to-fit-with-cropping on Android 7.0+ so it covers the full app view without empty bars.
- Status and navigation bars are transparent and the app content draws behind them.
- Existing login screen, panel, Gemini bubble, and settings are retained.
Replace the project ZIP in the repository and use the existing build-apk.yml workflow.
