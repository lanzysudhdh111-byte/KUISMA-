KUISMA launcher icon added: adaptive icon for Android 8+ and PNG fallback icons for older Android versions. AndroidManifest now references @mipmap/ic_launcher and @mipmap/ic_launcher_round.
