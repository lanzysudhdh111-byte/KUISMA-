package com.lanz.kuisma;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;

public class ReminderReceiver extends BroadcastReceiver {
    private static final int REQUEST_CODE = 1002;
    private static final long ONE_HOUR_MS = 60L * 60L * 1000L;

    public static void scheduleNext(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        long triggerAt = SystemClock.elapsedRealtime() + ONE_HOUR_MS;
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pending);
        } else {
            alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pending);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        // Restore the hourly reminder after a device reboot.
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            scheduleNext(context);
            return;
        }

        // Schedule the next reminder first, so it repeats every hour.
        scheduleNext(context);

        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("kuisma_updates", "Notifikasi KUISMA", NotificationManager.IMPORTANCE_DEFAULT);
            manager.createNotificationChannel(channel);
        }
        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(context, "kuisma_updates")
                : new android.app.Notification.Builder(context);
        String message = "halo apk ini buat ujian ya bukan apa apa , developer: LanzXytre";
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("APK KUISMA")
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true);
        manager.notify(1002, builder.build());
    }
}
