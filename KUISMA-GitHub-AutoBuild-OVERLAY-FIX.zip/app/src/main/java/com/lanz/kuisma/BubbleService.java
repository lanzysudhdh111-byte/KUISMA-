package com.lanz.kuisma;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class BubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;
    private int startX, startY;
    private float touchX, touchY;
    private static final String CHANNEL = "kuisma_overlay";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setContentTitle("KUISMA PLP Assistant aktif")
            .setContentText("Tombol Gemini melayang tersedia.")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        startForeground(7, notification);
        showBubble();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "KUISMA PLP Assistant", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    private void showBubble() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        TextView view = new TextView(this);
        view.setText("<>");
        view.setTextColor(Color.WHITE);
        view.setTextSize(19);
        view.setGravity(Gravity.CENTER);
        view.setElevation(12f);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.argb(105, 25, 105, 220));
        bg.setStroke(2, Color.argb(210, 160, 215, 255));
        view.setBackground(bg);
        bubble = view;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(14); params.y = dp(180);
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX=params.x; startY=params.y; touchX=event.getRawX(); touchY=event.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    params.x=startX+(int)(event.getRawX()-touchX);
                    params.y=startY+(int)(event.getRawY()-touchY);
                    wm.updateViewLayout(bubble,params); return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(event.getRawX()-touchX)<dp(8) && Math.abs(event.getRawY()-touchY)<dp(8)) {
                        Intent open=new Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/"));
                        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(open);
                    }
                    return true;
            }
            return false;
        });
        wm.addView(bubble,params);
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_STICKY; }
    @Override public void onDestroy(){ if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
