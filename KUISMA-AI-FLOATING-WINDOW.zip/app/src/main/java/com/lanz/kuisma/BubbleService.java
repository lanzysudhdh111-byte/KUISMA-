package com.lanz.kuisma;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class BubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams bubbleParams;
    private View panel;
    private WindowManager.LayoutParams panelParams;
    private int dragStartX, dragStartY;
    private float touchStartX, touchStartY;
    private static final String CHANNEL = "kuisma_overlay";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setContentTitle("KUISMA AI aktif")
            .setContentText("Ketuk tombol <> untuk membuka jendela AI.")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        startForeground(7, notification);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "KUISMA AI", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }

    private void showBubble() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        TextView view = new TextView(this);
        view.setText("<>"); view.setTextColor(Color.WHITE); view.setTextSize(19); view.setGravity(Gravity.CENTER); view.setElevation(dp(8));
        GradientDrawable bg = new GradientDrawable(); bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.argb(190, 25, 105, 220)); bg.setStroke(dp(2), Color.argb(230, 190, 225, 255)); view.setBackground(bg);
        bubble = view;
        bubbleParams = new WindowManager.LayoutParams(dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START; bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = bubbleParams.x; dragStartY = bubbleParams.y; touchStartX = event.getRawX(); touchStartY = event.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    bubbleParams.x = dragStartX + (int)(event.getRawX() - touchStartX);
                    bubbleParams.y = dragStartY + (int)(event.getRawY() - touchStartY);
                    try { wm.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {} return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(event.getRawX()-touchStartX) < dp(8) && Math.abs(event.getRawY()-touchStartY) < dp(8)) togglePanel();
                    return true;
            }
            return true;
        });
        wm.addView(bubble, bubbleParams);
    }

    private void togglePanel() { if (panel == null) showPanel(); else hidePanel(); }

    private void showPanel() {
        if (panel != null) return;
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable(); panelBg.setColor(Color.rgb(20, 25, 36)); panelBg.setCornerRadius(dp(16)); panelBg.setStroke(dp(1), Color.rgb(90, 145, 210));
        root.setBackground(panelBg); root.setClipToOutline(true);

        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(10), dp(5), dp(6), dp(5));
        bar.setBackgroundColor(Color.rgb(31, 43, 62));
        TextView title = new TextView(this); title.setText("KUISMA · AI WEB"); title.setTextColor(Color.WHITE); title.setTextSize(13); title.setTypeface(null, 1);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button smaller = smallButton("−"); Button larger = smallButton("+"); Button close = smallButton("×");
        bar.addView(smaller); bar.addView(larger); bar.addView(close);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(48)));

        WebView web = new WebView(this);
        WebSettings settings = web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true); settings.setUseWideViewPort(true); settings.setBuiltInZoomControls(true); settings.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("https://gemini.google.com/");
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView hint = new TextView(this); hint.setText("Tarik bar atas untuk memindahkan · − / + untuk mengubah ukuran");
        hint.setTextColor(Color.LTGRAY); hint.setTextSize(10); hint.setGravity(Gravity.CENTER); hint.setPadding(dp(4), dp(4), dp(4), dp(6));
        root.addView(hint, new LinearLayout.LayoutParams(-1, dp(24)));

        panel = root;
        panelParams = new WindowManager.LayoutParams(dp(310), dp(470), overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(66); panelParams.y = dp(105);
        wm.addView(panel, panelParams);

        bar.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = panelParams.x; dragStartY = panelParams.y; touchStartX = event.getRawX(); touchStartY = event.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    panelParams.x = dragStartX + (int)(event.getRawX() - touchStartX);
                    panelParams.y = dragStartY + (int)(event.getRawY() - touchStartY);
                    try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {} return true;
                default: return true;
            }
        });
        smaller.setOnClickListener(v -> resizePanel(-dp(40)));
        larger.setOnClickListener(v -> resizePanel(dp(40)));
        close.setOnClickListener(v -> hidePanel());
    }

    private Button smallButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(18); b.setPadding(0, 0, 0, 0);
        b.setMinWidth(dp(38)); b.setMinimumWidth(dp(38)); b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38));
        return b;
    }

    private void resizePanel(int delta) {
        if (panel == null || panelParams == null) return;
        panelParams.width = Math.max(dp(230), Math.min(dp(420), panelParams.width + delta));
        panelParams.height = Math.max(dp(300), Math.min(dp(700), panelParams.height + delta));
        try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
    }

    private void hidePanel() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; panelParams = null; }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        hidePanel();
        if (wm != null && bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
