package com.lanz.kuisma;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 56, 36, 36);
        TextView title = new TextView(this);
        title.setText("KUISMA · PLP ASSISTANT\n\nAktifkan izin 'Tampilkan di atas aplikasi lain' untuk memakai tombol bulat transparan di atas Chrome. Ketuk tombol <> untuk membuka jendela AI di samping tombol. Jendela bisa dipindah dan ukurannya bisa diubah dengan tombol + dan −.");
        title.setTextSize(18);
        layout.addView(title);
        Button enable = new Button(this);
        enable.setText("Aktifkan tombol melayang");
        layout.addView(enable);
        Button stop = new Button(this);
        stop.setText("Matikan tombol melayang");
        layout.addView(stop);

        TextView bubbleSettingsTitle = new TextView(this);
        bubbleSettingsTitle.setText("Pengaturan tombol melayang");
        bubbleSettingsTitle.setTextSize(17);
        bubbleSettingsTitle.setPadding(0, dp(18), 0, dp(6));
        layout.addView(bubbleSettingsTitle);

        android.content.SharedPreferences prefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);
        int savedSize = prefs.getInt("bubble_size", 56);
        int savedOpacity = prefs.getInt("bubble_opacity", 85);

        TextView sizeLabel = new TextView(this);
        sizeLabel.setText("Ukuran tombol: " + savedSize + " dp");
        layout.addView(sizeLabel);
        SeekBar sizeSeek = new SeekBar(this);
        sizeSeek.setMax(60);
        sizeSeek.setProgress(savedSize - 40);
        layout.addView(sizeSeek);

        TextView opacityLabel = new TextView(this);
        opacityLabel.setText("Transparansi tombol: " + savedOpacity + "%");
        layout.addView(opacityLabel);
        SeekBar opacitySeek = new SeekBar(this);
        opacitySeek.setMax(100);
        opacitySeek.setProgress(savedOpacity);
        layout.addView(opacitySeek);

        setContentView(layout);
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = 40 + progress;
                sizeLabel.setText("Ukuran tombol: " + value + " dp");
                prefs.edit().putInt("bubble_size", value).apply();
                sendBubbleSettingsChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        opacitySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = Math.max(15, progress);
                opacityLabel.setText("Transparansi tombol: " + value + "%");
                prefs.edit().putInt("bubble_opacity", value).apply();
                sendBubbleSettingsChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else startBubble();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, BubbleService.class)));
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startBubble();
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }

    private void sendBubbleSettingsChanged() {
        Intent update = new Intent("com.lanz.kuisma.BUBBLE_SETTINGS_CHANGED");
        update.setPackage(getPackageName());
        sendBroadcast(update);
    }

    private void startBubble() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, BubbleService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Tombol melayang sedang diaktifkan.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengaktifkan tombol: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
