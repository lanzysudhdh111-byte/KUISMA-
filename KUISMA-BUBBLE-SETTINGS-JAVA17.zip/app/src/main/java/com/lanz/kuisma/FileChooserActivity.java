package com.lanz.kuisma;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;

/** Small transparent activity used by WebView's HTML file input. */
public class FileChooserActivity extends Activity {
    private static final int PICK_IMAGE = 7412;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(pick, PICK_IMAGE);
        } catch (Exception e) {
            finishWithResult(null);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            results = new Uri[]{data.getData()};
            try { getContentResolver().takePersistableUriPermission(results[0], Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
        }
        finishWithResult(results);
    }

    private void finishWithResult(Uri[] result) {
        ValueCallback<Uri[]> callback = BubbleService.pendingFileCallback;
        BubbleService.pendingFileCallback = null;
        if (callback != null) callback.onReceiveValue(result);
        finish();
    }

    @Override public void onBackPressed() {
        finishWithResult(null);
    }
}
