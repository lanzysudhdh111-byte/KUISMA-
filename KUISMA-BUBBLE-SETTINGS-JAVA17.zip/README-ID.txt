KUISMA - SOURCE APK ANDROID

PROJECT INI ADALAH PENDAMPING BELAJAR/LATIHAN OFFLINE.
Bukan pengisi ujian aktif otomatis. Versi ini belum memakai model AI generatif
dan tidak menjamin jawaban benar 100%.

CARA BUILD GRATIS VIA GITHUB (CUKUP ZIP + 1 FILE WORKFLOW)
1. Upload file KUISMA-GitHub-AutoBuild-FIXED.zip ke halaman utama repository.
2. Pastikan file .github/workflows/build-apk.yml di repository memakai versi
   dari ZIP ini. Jika belum, ganti file workflow tersebut dengan yang ada
   di dalam ZIP (path: .github/workflows/build-apk.yml).
3. Buka tab Actions.
4. Pilih "Build KUISMA APK", tekan "Run workflow".
5. Tunggu sampai status Success/hijau.
6. Buka run yang berhasil, lalu di bagian Artifacts unduh KUISMA-debug-APK.
7. Ekstrak ZIP artifact; file app-debug.apk ada di dalamnya.

Workflow akan mengekstrak ZIP project secara otomatis di GitHub, jadi folder
app dan file Gradle tidak perlu diunggah satu per satu.

CATATAN:
- Workflow menggunakan Android SDK setup v3, Java 17, Gradle 8.7,
  Android platform 35, dan build-tools 35.0.0.
- Log persetujuan lisensi Android SDK disenyapkan agar tidak memenuhi layar.
- APK debug ini untuk instalasi/uji coba, bukan rilis Play Store.
- Jika build masih gagal, kirim screenshot step yang gagal atau log error
  bagian akhir; keberhasilan build belum bisa dipastikan sebelum Actions hijau.

BUILD DARI HP DENGAN ANDROIDIDE (ALTERNATIF)
1. Ekstrak ZIP.
2. Buka AndroidIDE > Open Project.
3. Pilih folder yang berisi settings.gradle.
4. Tunggu Gradle sync selesai.
5. Jalankan task :app:assembleDebug.
6. APK ada di app/build/outputs/apk/debug/app-debug.apk.

SERVER.JS OPSIONAL:
Di komputer/VPS: npm install lalu npm start.

FITUR TAMBAHAN PLP ASSISTANT
- Aplikasi KUISMA kini menyertakan tombol overlay bulat transparan <>.
- Buka APK, pilih Aktifkan tombol melayang, lalu setujui izin Android "Tampilkan di atas aplikasi lain".
- Tombol dapat digeser di atas aplikasi lain. Ketuk untuk membuka Gemini di jendela WebView melayang, bukan berpindah ke Chrome.
- Jendela AI dapat digeser dari bar judul dan ukurannya dapat diubah dengan tombol + dan −; tombol × menutup jendela.
- Untuk menghentikan overlay, buka kembali aplikasi KUISMA PLP Assistant dan tekan Matikan tombol melayang.
- Gemini tetap mengikuti dukungan browser, login, dan kebijakan Google.
- Fitur ini hanya membuka Gemini; tidak membaca layar atau mengisi jawaban ujian otomatis.

PERBAIKAN UPLOAD FOTO GEMINI
- WebView sekarang menangani HTML file chooser melalui onShowFileChooser.
- Saat tombol lampiran Gemini ditekan, Android membuka pemilih gambar sistem.
- Pilih gambar dari galeri/penyimpanan, lalu kembali ke jendela Gemini.
- Workflow GitHub Actions tidak diubah. Tetap gunakan build-apk.yml yang sudah ada di repository.

Catatan: keberhasilan upload tetap bergantung pada dukungan Gemini terhadap WebView dan status login Google. Jika Google menolak login atau upload di WebView, itu pembatasan dari situs dan tidak dapat dijamin hanya dengan kode pemilih file.
