package com.lanz.kuisma;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(layout);

        TextView title = new TextView(this);
        title.setText("KUISMA · AI WEB\n\nAktifkan tombol melayang untuk membuka Gemini dalam jendela kecil di atas aplikasi lain.");
        title.setTextSize(18);
        layout.addView(title);

        Button enable = new Button(this);
        enable.setText("Aktifkan tombol melayang");
        layout.addView(enable);
        Button stop = new Button(this);
        stop.setText("Matikan tombol melayang");
        layout.addView(stop);

        TextView settingsTitle = new TextView(this);
        settingsTitle.setText("Pengaturan tombol buka Gemini");
        settingsTitle.setTextSize(19);
        settingsTitle.setPadding(0, dp(22), 0, dp(8));
        settingsTitle.setTypeface(null, 1);
        layout.addView(settingsTitle);

        addSlider(layout, "Ukuran tombol buka Gemini", "bubble_size", 40, 100, 56, " dp");
        addSlider(layout, "Transparansi tombol buka Gemini", "bubble_opacity", 0, 100, 85, "%");

        TextView note = new TextView(this);
        note.setText("Pengaturan ini mengubah tombol bulat <> yang digunakan untuk membuka Gemini, bukan ukuran jendela web Gemini. Perubahan diterapkan langsung saat tombol melayang aktif.");
        note.setTextSize(13);
        note.setPadding(0, dp(12), 0, dp(8));
        layout.addView(note);

        setContentView(scroll);
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else startBubble();
        });
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, BubbleService.class));
            Toast.makeText(this, "Tombol melayang dimatikan.", Toast.LENGTH_SHORT).show();
        });
    }

    private void addSlider(LinearLayout parent, String title, String key, int min, int max, int fallback, String suffix) {
        int current = prefs.getInt(key, fallback);
        TextView label = new TextView(this);
        label.setText(title + ": " + current + suffix);
        label.setTextSize(15);
        label.setPadding(0, dp(10), 0, 0);
        parent.addView(label);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(Math.max(0, Math.min(max - min, current - min)));
        parent.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = min + progress;
                label.setText(title + ": " + value + suffix);
                if (fromUser) {
                    prefs.edit().putInt(key, value).apply();
                    sendBubbleSettingsChanged();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }
    private void sendBubbleSettingsChanged() {
        Intent update = new Intent("com.lanz.kuisma.BUBBLE_SETTINGS_CHANGED");
        update.setPackage(getPackageName());
        sendBroadcast(update);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startBubble();
    }

    private void startBubble() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, BubbleService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Tombol melayang diaktifkan.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengaktifkan tombol: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
