package com.lanz.kuisma;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.view.TextureView;
import android.view.Surface;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class BubbleService extends Service {
    public static ValueCallback<Uri[]> pendingFileCallback;
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams bubbleParams;
    private View panel;
    private WindowManager.LayoutParams panelParams;
    private MediaPlayer panelVideoPlayer;
    private Surface panelVideoSurface;
    private int dragStartX, dragStartY;
    private float touchStartX, touchStartY;
    private static final String CHANNEL = "kuisma_overlay";
    private float[] panelAlphaLevels = new float[]{1.0f, 0.88f, 0.76f, 0.64f};
    private int panelAlphaIndex = 0;
    private Button transparencyButton;
    private TextView bubbleText;
    private BroadcastReceiver bubbleSettingsReceiver;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setContentTitle("KUISMA AI aktif")
            .setContentText("Ketuk tombol <> untuk membuka jendela AI.")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        startForeground(7, notification);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubbleSettingsReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                applyBubbleSettings();
                applyPanelSettings();
            }
        };
        IntentFilter filter = new IntentFilter("com.lanz.kuisma.BUBBLE_SETTINGS_CHANGED");
        filter.addAction("com.lanz.kuisma.PANEL_SETTINGS_CHANGED");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(bubbleSettingsReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(bubbleSettingsReceiver, filter);
        showBubble();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "KUISMA AI", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }

    private void showBubble() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        TextView view = new TextView(this);
        bubbleText = view;
        view.setText("<>"); view.setTextColor(Color.WHITE); view.setTextSize(19); view.setGravity(Gravity.CENTER); view.setElevation(dp(8));
        GradientDrawable bg = new GradientDrawable(); bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.argb(190, 25, 105, 220)); bg.setStroke(dp(2), Color.argb(230, 190, 225, 255)); view.setBackground(bg);
        bubble = view;
        int initialSize = getSharedPreferences("kuisma_overlay", MODE_PRIVATE).getInt("bubble_size", 56);
        bubbleParams = new WindowManager.LayoutParams(dp(initialSize), dp(initialSize), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START; bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = bubbleParams.x; dragStartY = bubbleParams.y; touchStartX = event.getRawX(); touchStartY = event.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    bubbleParams.x = dragStartX + (int)(event.getRawX() - touchStartX);
                    bubbleParams.y = dragStartY + (int)(event.getRawY() - touchStartY);
                    try { wm.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {} return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(event.getRawX()-touchStartX) < dp(8) && Math.abs(event.getRawY()-touchStartY) < dp(8)) togglePanel();
                    return true;
            }
            return true;
        });
        wm.addView(bubble, bubbleParams);
        applyBubbleSettings();
    }

    private void applyBubbleSettings() {
        if (bubble == null || bubbleParams == null) return;
        android.content.SharedPreferences prefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);
        int size = prefs.getInt("bubble_size", 56);
        int opacity = prefs.getInt("bubble_opacity", 85);
        bubbleParams.width = dp(size);
        bubbleParams.height = dp(size);
        bubble.setAlpha(Math.max(0.0f, Math.min(1f, opacity / 100f)));
        if (bubbleText != null) bubbleText.setTextSize(Math.max(12f, Math.min(26f, size * 0.34f)));
        try { wm.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) { }
    }

    private void togglePanel() { if (panel == null) showPanel(); else hidePanel(); }

    private void showPanel() {
        if (panel != null) return;

        // FrameLayout lets the supplied video sit behind the panel chrome.
        // The Gemini WebView remains interactive and occupies the main content area.
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(20, 25, 36));

        TextureView videoBackground = new TextureView(this);
        frame.addView(videoBackground, new FrameLayout.LayoutParams(-1, -1));
        videoBackground.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture texture, int width, int height) {
                startPanelBackgroundVideo(texture);
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture texture, int width, int height) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture texture) {
                releasePanelBackgroundVideo();
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture texture) { }
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(-1, -1);
        frame.addView(content, contentParams);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(5), dp(6), dp(5));
        bar.setBackgroundColor(Color.argb(205, 31, 43, 62));
        TextView title = new TextView(this);
        title.setText("KUISMA · AI WEB");
        title.setTextColor(Color.WHITE);
        title.setTextSize(13);
        title.setTypeface(null, 1);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button smaller = smallButton("−");
        Button larger = smallButton("+");
        transparencyButton = smallButton("◐");
        transparencyButton.setTextSize(15);
        transparencyButton.setContentDescription("Ubah transparansi jendela");
        Button close = smallButton("×");
        bar.addView(smaller);
        bar.addView(larger);
        bar.addView(transparencyButton);
        bar.addView(close);
        content.addView(bar, new LinearLayout.LayoutParams(-1, dp(48)));

        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                Intent picker = new Intent(BubbleService.this, FileChooserActivity.class);
                picker.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                try {
                    startActivity(picker);
                    return true;
                } catch (Exception e) {
                    pendingFileCallback = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
            }
        });
        web.loadUrl("https://gemini.google.com/");
        content.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView hint = new TextView(this);
        hint.setText("Tarik bar atas untuk memindahkan · − / + untuk mengubah ukuran");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(10);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(4), dp(4), dp(4), dp(6));
        hint.setBackgroundColor(Color.argb(190, 20, 25, 36));
        content.addView(hint, new LinearLayout.LayoutParams(-1, dp(24)));

        panel = frame;
        android.content.SharedPreferences panelPrefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);
        int savedWidth = panelPrefs.getInt("panel_width", 310);
        int savedHeight = panelPrefs.getInt("panel_height", 470);
        int savedOpacity = panelPrefs.getInt("panel_opacity", 100);
        panelParams = new WindowManager.LayoutParams(dp(savedWidth), dp(savedHeight), overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.alpha = Math.max(0.5f, Math.min(1f, savedOpacity / 100f));
        panelParams.x = dp(66);
        panelParams.y = dp(105);
        wm.addView(panel, panelParams);

        bar.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartX = panelParams.x;
                    dragStartY = panelParams.y;
                    touchStartX = event.getRawX();
                    touchStartY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    panelParams.x = dragStartX + (int)(event.getRawX() - touchStartX);
                    panelParams.y = dragStartY + (int)(event.getRawY() - touchStartY);
                    try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) { }
                    return true;
                default:
                    return true;
            }
        });
        smaller.setOnClickListener(v -> resizePanel(-dp(40)));
        larger.setOnClickListener(v -> resizePanel(dp(40)));
        transparencyButton.setOnClickListener(v -> cyclePanelTransparency());
        close.setOnClickListener(v -> hidePanel());
    }

    private void startPanelBackgroundVideo(SurfaceTexture texture) {
        releasePanelBackgroundVideo();
        try {
            panelVideoSurface = new Surface(texture);
            panelVideoPlayer = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.panel_bg);
            if (afd == null) throw new IllegalStateException("Video background tidak ditemukan");
            panelVideoPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            panelVideoPlayer.setSurface(panelVideoSurface);
            panelVideoPlayer.setLooping(true);
            panelVideoPlayer.setVolume(0f, 0f);
            panelVideoPlayer.setOnPreparedListener(mp -> mp.start());
            panelVideoPlayer.setOnErrorListener((mp, what, extra) -> true);
            panelVideoPlayer.prepareAsync();
        } catch (Exception e) {
            releasePanelBackgroundVideo();
        }
    }

    private void releasePanelBackgroundVideo() {
        if (panelVideoPlayer != null) {
            try { panelVideoPlayer.stop(); } catch (Exception ignored) { }
            try { panelVideoPlayer.reset(); } catch (Exception ignored) { }
            try { panelVideoPlayer.release(); } catch (Exception ignored) { }
            panelVideoPlayer = null;
        }
        if (panelVideoSurface != null) {
            try { panelVideoSurface.release(); } catch (Exception ignored) { }
            panelVideoSurface = null;
        }
    }

    private Button smallButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(18); b.setPadding(0, 0, 0, 0);
        b.setMinWidth(dp(38)); b.setMinimumWidth(dp(38)); b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38));
        return b;
    }

    private void applyPanelSettings() {
        if (panel == null || panelParams == null) return;
        android.content.SharedPreferences prefs = getSharedPreferences("kuisma_overlay", MODE_PRIVATE);
        int width = prefs.getInt("panel_width", 310);
        int height = prefs.getInt("panel_height", 470);
        int opacity = prefs.getInt("panel_opacity", 100);
        panelParams.width = dp(Math.max(230, Math.min(420, width)));
        panelParams.height = dp(Math.max(300, Math.min(700, height)));
        panelParams.alpha = Math.max(0.5f, Math.min(1f, opacity / 100f));
        try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) { }
        if (transparencyButton != null) {
            transparencyButton.setText(opacity + "%");
            transparencyButton.setTextSize(10);
        }
    }

    private void resizePanel(int delta) {
        if (panel == null || panelParams == null) return;
        panelParams.width = Math.max(dp(230), Math.min(dp(420), panelParams.width + delta));
        panelParams.height = Math.max(dp(300), Math.min(dp(700), panelParams.height + delta));
        getSharedPreferences("kuisma_overlay", MODE_PRIVATE).edit()
            .putInt("panel_width", Math.round(panelParams.width / getResources().getDisplayMetrics().density))
            .putInt("panel_height", Math.round(panelParams.height / getResources().getDisplayMetrics().density)).apply();
        try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
    }

    private void cyclePanelTransparency() {
        if (panel == null || panelParams == null) return;
        int current = getSharedPreferences("kuisma_overlay", MODE_PRIVATE).getInt("panel_opacity", 100);
        int next = current <= 64 ? 100 : current - 12;
        if (next < 50) next = 50;
        getSharedPreferences("kuisma_overlay", MODE_PRIVATE).edit().putInt("panel_opacity", next).apply();
        applyPanelSettings();
    }

    private void hidePanel() {
        releasePanelBackgroundVideo();
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; panelParams = null; }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (pendingFileCallback != null) { pendingFileCallback.onReceiveValue(null); pendingFileCallback = null; }
        if (bubbleSettingsReceiver != null) {
            try { unregisterReceiver(bubbleSettingsReceiver); } catch (Exception ignored) { }
            bubbleSettingsReceiver = null;
        }
        hidePanel();
        if (wm != null && bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
