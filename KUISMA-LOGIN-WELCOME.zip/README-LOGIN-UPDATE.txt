KUISMA welcome screen update
- First screen shows APK KUISMA, developer: LanzXytre, and LOGIN only.
- LOGIN opens the existing KUISMA menu directly; no account/password is requested.
- Existing video background and floating Gemini controls are retained.
- Existing build-apk.yml can remain unchanged.
