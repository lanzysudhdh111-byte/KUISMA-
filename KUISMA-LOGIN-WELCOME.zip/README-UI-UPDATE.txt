KUISMA UI UPDATE
- MainActivity now displays the supplied MP4 as a muted looping background.
- Dark translucent overlay and glass-style rounded action buttons are used for readability.
- Existing overlay bubble size/transparency settings and service behavior are retained.
- Existing GitHub Actions workflow can remain unchanged.
