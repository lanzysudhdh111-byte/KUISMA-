KUISMA - SOURCE APK ANDROID

BUILD GRATIS DARI HP:
1. Ekstrak ZIP.
2. Instal AndroidIDE dari https://m.androidide.com/
3. Buka AndroidIDE > Open Project, pilih folder KUISMA (yang berisi settings.gradle).
4. Tunggu Gradle sync. Internet diperlukan saat pertama kali mengunduh Android SDK/Gradle.
5. Jalankan task :app:assembleDebug atau pilih Build > Assemble.
6. APK ada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN PENTING:
- Ini source project, bukan APK yang sudah dikompilasi.
- Versi ini offline dan belum menyertakan model AI generatif. Fitur yang ada membuat pertanyaan pemahaman dari materi, memberi panduan analisis, dan menyimpan catatan.
- Belum mendukung OCR foto atau jawaban otomatis; tidak menjamin akurasi 100%.
- Untuk AI lokal sungguhan diperlukan integrasi model on-device yang ukurannya besar dan sesuai kemampuan HP.

SERVER.JS OPSIONAL:
Di komputer/VPS: npm install lalu npm start. Buka http://localhost:3000.

BUILD APK OTOMATIS VIA GITHUB ACTIONS (TANPA BUILD DI HP)
1. Buat repository GitHub baru, misalnya KUISMA.
2. Ekstrak ZIP ini, lalu unggah SEMUA isi folder (termasuk folder .github) ke repository.
   Pastikan file .github/workflows/build-apk.yml ikut terunggah.
3. Buka tab Actions di repository. Jika diminta, izinkan Actions.
4. Pilih workflow "Build KUISMA APK", tekan Run workflow.
5. Tunggu sampai proses berstatus hijau/Success.
6. Buka hasil run tersebut, bagian Artifacts, lalu download KUISMA-debug-APK.
7. Ekstrak ZIP artifact dan instal app-debug.apk di HP.

Workflow ini hanya membuat APK debug dari source. APK belum ditandatangani sebagai rilis Play Store.
