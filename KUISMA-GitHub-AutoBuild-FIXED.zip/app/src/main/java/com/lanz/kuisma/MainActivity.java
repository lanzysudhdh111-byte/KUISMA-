package com.lanz.kuisma;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 410;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 56, 36, 36);
        TextView title = new TextView(this);
        title.setText("KUISMA · PLP ASSISTANT\n\nAktifkan izin 'Tampilkan di atas aplikasi lain' untuk memakai tombol bulat transparan di atas Chrome. Ketuk tombol untuk membuka Gemini sebagai pendamping belajar.");
        title.setTextSize(18);
        layout.addView(title);
        Button enable = new Button(this);
        enable.setText("Aktifkan tombol melayang");
        layout.addView(enable);
        Button stop = new Button(this);
        stop.setText("Matikan tombol melayang");
        layout.addView(stop);
        setContentView(layout);
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else startBubble();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, BubbleService.class)));
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) startBubble();
    }
    private void startBubble() {
        Intent i = new Intent(this, BubbleService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        finish();
    }
}
